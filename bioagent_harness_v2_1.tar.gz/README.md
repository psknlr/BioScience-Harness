# bioagent-harness v2.1 — a composable harness for biomedical AI agents

## v2.1 — what changed
- Ten architectural defects fixed, each pinned by a regression test (`tests/test_v21_regressions.py`);
  one was security-class (path traversal into the immutable policy plane).
- `HTTPBackend` (REST + GraphQL, stdlib-only) with per-host rate limits, retries, response cache.
- 16 public data-source connectors, 45 typed operations, all verified live
  (`data/connector_live_verification.csv`): Ensembl, UniProt, NCBI E-utilities, ChEMBL, PubChem,
  ClinicalTrials.gov, openFDA, STRING, KEGG, Reactome, Open Targets, RCSB PDB, Europe PMC, gnomAD,
  MyGene, MyVariant.
- Acquisition layer: `AcquisitionSpec`, resumable checksum-verified `Downloader`, FETCHABLE resolution,
  `AgentSpec(auto_fetch=True)`, and a CLI:

      PYTHONPATH=src python -m bioagent.cli sources
      PYTHONPATH=src python -m bioagent.cli fetchable
      PYTHONPATH=src python -m bioagent.cli fetch hgnc.dataset.hgnc_complete_set_txt

- Executable-now components: 76 → 96. 764 more have a verified-live equivalent source (routable,
  not yet dispatched per component). See `data/capability_state_census_v21.csv`.


Built from a survey of 16 biomedical agent projects (2,567 catalogued capabilities).
v2 rebuilds the v1 scaffold as a **component runtime**: one manifest schema, a trusted
policy kernel, pluggable execution backends, event-sourced provenance, and a validated
self-evolution pipeline.

## What v2 corrects

v1 reported 621 capabilities as "confirmed routable". That was a routing decision, never a
dispatch. v2 measures executability against the live environment and reports it honestly:

    catalogued        2,567  (100%)
    dependency-ok     1,024  (39.9%)
    executable now       76  (3.0%)   <- all datasets

Nine v1 defects were reproduced empirically and fixed; each has a regression test in
`tests/test_regressions.py`.

## Layout

    src/bioagent/
      status.py            ExecutionStatus, LifecycleState, RunOutcome + transition table
      policy.py            immutable policy kernel (read-only license/permission tables)
      config.py            path resolution: argument -> env var -> repo-relative
      runtime/
        component.py       ComponentManifest (the one composable unit)
        registry.py        ComponentRegistry / Resolver / Loader
        events.py          event-sourced provenance with graph replay
        hmr.py             transactional hot reload + LazyComponentSet
        agentspec.py       AgentSpec (data) + Runtime (executes any spec)
      backends/            python | mcp | dataset | subprocess | container | none
      providers/           discovery from catalogue rows and SKILL.md trees
      planners/            self-registering plugins: heuristic, llm
      evolution/           propose -> test -> benchmark -> policy -> promote
      workspace/           file workspace with an enforced trust boundary + git
      adapters/            v1 adapters (retained; superseded by backends)

## Quick start

    export PYTHONPATH=src
    export BIOAGENT_DATA_LAKE=/path/to/biomni_lake     # optional
    python demo_harness.py                             # full v2 demo
    python -m pytest -q                                # 64 pass with the lake
    python -m pytest -q -m unit                        # 60 pass without it

## Tests

    tests/test_regressions.py   pins all 8 v1 blocker defects
    tests/test_v2_harness.py    manifests, lifecycle, policy, backends, HMR, evolution
    tests/test_bioagent.py      v1 surface (migrated to status semantics)

## Honesty notes

* No container runtime on the build machine, so filesystem/network isolation is reported
  as unavailable rather than implied.
* This sandbox refuses to lower RLIMIT_AS, so `HardenedExecutor.guarantees()` probes what
  is actually enforced (CPU + file size) and reports the memory cap as unenforced.
* The Biomni data lake (15.1 GB) is not redistributable; only its inventory ships here.
* Unlicensed upstream projects are never vendored — they are invoked in place, and the
  policy kernel denies a vendor route for them on every call.

## License

MIT for this harness. `NOTICE` records every upstream project, its license, and whether it
is vendorable or federated-only.
