"""Trusted policy kernel — license, permission and secret rules.

This module is the immutable plane. Nothing an agent authors may modify it, and
no invocation may bypass it: the runtime consults `PolicyKernel.authorize()`
between resolution and execution, so a capability cannot reach a backend without
a recorded decision.

The v1 defect this fixes: `Adapter.assert_may_vendor()` existed but was called
only from a test, so the license boundary was documentation, not enforcement.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Iterable, Mapping


class PolicyDecision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    PREFER_ALTERNATIVE = "PREFER_ALTERNATIVE"


@dataclass(frozen=True)
class Ruling:
    """A policy decision with the reason that produced it."""

    decision: PolicyDecision
    reason: str
    rule: str = ""

    @property
    def allowed(self) -> bool:
        return self.decision is not PolicyDecision.DENY


#: SPDX ids that permit reusing (vendoring) upstream implementation code.
PERMISSIVE_SPDX = frozenset({
    "MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC",
    "NLM-Public-Domain", "CC0-1.0", "Unlicense",
})

#: Treated as "no license granted" — all rights reserved by default.
NO_LICENSE_SPDX = frozenset({"NONE", "NOASSERTION", "", "UNKNOWN"})

#: license class -> integration mode -> ruling
_DEFAULT_LICENSE_POLICY: Mapping[str, Mapping[str, PolicyDecision]] = MappingProxyType({
    "permissive": MappingProxyType({
        "vendor": PolicyDecision.ALLOW,
        "native": PolicyDecision.ALLOW,
        "federated": PolicyDecision.ALLOW,
    }),
    "none": MappingProxyType({
        # Copying code from a project that grants no license is not permitted.
        "vendor": PolicyDecision.DENY,
        # Calling a native equivalent avoids the upstream code entirely.
        "native": PolicyDecision.ALLOW,
        # Invoking the upstream in its own process is use, not redistribution.
        "federated": PolicyDecision.ALLOW,
    }),
    "copyleft": MappingProxyType({
        "vendor": PolicyDecision.PREFER_ALTERNATIVE,
        "native": PolicyDecision.ALLOW,
        "federated": PolicyDecision.ALLOW,
    }),
})

COPYLEFT_SPDX = frozenset({"GPL-2.0", "GPL-3.0", "AGPL-3.0", "LGPL-3.0", "LGPL-2.1"})


def license_class(spdx: str | None) -> str:
    s = (spdx or "").strip()
    if s in PERMISSIVE_SPDX:
        return "permissive"
    if s in COPYLEFT_SPDX:
        return "copyleft"
    if s in NO_LICENSE_SPDX:
        return "none"
    return "none"  # unrecognized ⇒ treat as all-rights-reserved (fail closed)


class LicensePolicy:
    """Decides whether a capability may be used through a given integration mode."""

    def __init__(self, table: Mapping[str, Mapping[str, PolicyDecision]] | None = None) -> None:
        self._table = table or _DEFAULT_LICENSE_POLICY

    def check(self, *, license_spdx: str | None, integration_mode: str) -> Ruling:
        cls = license_class(license_spdx)
        mode = (integration_mode or "").strip().lower()
        # normalize the v1 vocabulary onto policy modes
        if mode in ("adapter-only", "adapter_only"):
            mode = "federated"
        decision = self._table.get(cls, {}).get(mode)
        if decision is None:
            return Ruling(PolicyDecision.DENY,
                          f"no rule for license class {cls!r} with mode {mode!r}",
                          rule="license.default_deny")
        if decision is PolicyDecision.DENY:
            return Ruling(decision,
                          f"{license_spdx or 'no license'} does not permit {mode} use; "
                          "invoke upstream in place or use a native equivalent",
                          rule=f"license.{cls}.{mode}")
        if decision is PolicyDecision.PREFER_ALTERNATIVE:
            return Ruling(decision,
                          f"{license_spdx} is copyleft; prefer a native equivalent before vendoring",
                          rule=f"license.{cls}.{mode}")
        return Ruling(decision, f"{license_spdx or 'unlicensed'} permits {mode} use",
                      rule=f"license.{cls}.{mode}")


@dataclass(frozen=True)
class PermissionProfile:
    """What a component is allowed to touch."""

    name: str = "default"
    allow_network: bool = False
    allowed_hosts: frozenset[str] = frozenset()
    allow_filesystem_read: frozenset[str] = frozenset()
    allow_filesystem_write: frozenset[str] = frozenset()
    allow_subprocess: bool = False

    def check_network(self, hosts: Iterable[str]) -> Ruling:
        hosts = [h for h in hosts if h]
        if not hosts:
            return Ruling(PolicyDecision.ALLOW, "no network access requested", "perm.network.none")
        if not self.allow_network:
            return Ruling(PolicyDecision.DENY,
                          f"profile {self.name!r} forbids network access (requested: {', '.join(hosts[:3])})",
                          "perm.network.denied")
        if self.allowed_hosts:
            bad = [h for h in hosts if not any(h == a or h.endswith("." + a) for a in self.allowed_hosts)]
            if bad:
                return Ruling(PolicyDecision.DENY,
                              f"hosts not in profile allowlist: {', '.join(bad[:3])}",
                              "perm.network.allowlist")
        return Ruling(PolicyDecision.ALLOW, "network permitted by profile", "perm.network.ok")


#: Profiles are defined here, in the trusted plane — not in agent-writable files.
PROFILES: Mapping[str, PermissionProfile] = MappingProxyType({
    "offline-analysis": PermissionProfile(name="offline-analysis", allow_network=False),
    "biomedical-research": PermissionProfile(
        name="biomedical-research", allow_network=True, allow_subprocess=True,
        # Every host below was verified live from the harness (see
        # catalogue_v2/connector_live_verification.csv). Suffix matching applies,
        # so "ncbi.nlm.nih.gov" also covers eutils./pubchem.ncbi.nlm.nih.gov.
        allowed_hosts=frozenset({
            "ncbi.nlm.nih.gov", "ebi.ac.uk", "ensembl.org", "rcsb.org", "uniprot.org",
            "clinicaltrials.gov", "api.fda.gov", "string-db.org", "reactome.org",
            "rest.kegg.jp", "opentargets.org", "gnomad.broadinstitute.org",
            "mygene.info", "myvariant.info",
            # bulk-data hosts used by the acquisition layer
            "biomni-release.s3.amazonaws.com", "storage.googleapis.com",
            "ftp.ebi.ac.uk", "stringdb-downloads.org", "genenames.org",
            # not yet verified live from this harness, retained from v2
            "genome.ucsc.edu", "monarchinitiative.org", "depmap.org",
        })),
    "sandbox-only": PermissionProfile(name="sandbox-only", allow_network=False, allow_subprocess=True),
})


@dataclass
class AuthorizationRequest:
    """Everything the kernel needs to rule on one invocation."""

    component_id: str
    license_spdx: str | None
    integration_mode: str
    backend: str = "python"
    network_hosts: tuple[str, ...] = ()
    profile: str = "biomedical-research"


@dataclass(frozen=True)
class Authorization:
    """The kernel's ruling, recorded in provenance whether allowed or denied."""

    component_id: str
    allowed: bool
    rulings: tuple[Ruling, ...] = field(default_factory=tuple)

    @property
    def reason(self) -> str:
        denied = [r for r in self.rulings if r.decision is PolicyDecision.DENY]
        if denied:
            return "; ".join(r.reason for r in denied)
        return "; ".join(r.reason for r in self.rulings) or "authorized"

    @property
    def denied_rules(self) -> tuple[str, ...]:
        return tuple(r.rule for r in self.rulings if r.decision is PolicyDecision.DENY)


class PolicyKernel:
    """The single gate every invocation passes through.

    Immutability is structural rather than advisory: the kernel holds its policy
    tables as read-only mappings and exposes no setter. Callers construct a
    kernel; agent-authored code cannot rewrite one.
    """

    def __init__(self, license_policy: LicensePolicy | None = None,
                 profiles: Mapping[str, PermissionProfile] | None = None) -> None:
        self._license = license_policy or LicensePolicy()
        self._profiles = MappingProxyType(dict(profiles or PROFILES))

    @property
    def license_policy(self) -> LicensePolicy:
        return self._license

    def profile(self, name: str) -> PermissionProfile:
        return self._profiles.get(name, PROFILES["offline-analysis"])

    def authorize(self, req: AuthorizationRequest) -> Authorization:
        rulings: list[Ruling] = [
            self._license.check(license_spdx=req.license_spdx,
                                integration_mode=req.integration_mode)
        ]
        prof = self.profile(req.profile)
        rulings.append(prof.check_network(req.network_hosts))
        if req.backend == "subprocess" and not prof.allow_subprocess:
            rulings.append(Ruling(PolicyDecision.DENY,
                                  f"profile {prof.name!r} forbids subprocess execution",
                                  "perm.subprocess.denied"))
        allowed = all(r.allowed for r in rulings)
        return Authorization(component_id=req.component_id, allowed=allowed,
                             rulings=tuple(rulings))
