"""Component registry, resolver and loader.

Division of labour, deliberately strict:

* **Registry** — discover, search, rank, resolve *identity*. It never executes.
* **Resolver** — check the dependency DAG and the live environment, and decide
  whether a component is genuinely READY or UNAVAILABLE (with the reason).
* **Loader** — lazily import an implementation, cache it, and unload it.

The resolver is where v1's central error is corrected: a component is only READY
if its declared requirements are actually satisfied *here*. On this machine 45 of
the 53 third-party imports Biomni's tools need are absent, so most components
resolve to UNAVAILABLE with a precise blocking reason instead of being counted as
available capability.
"""

from __future__ import annotations

import importlib
import importlib.util
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Sequence

from ..status import LifecycleState
from .component import ComponentManifest


class ComponentRegistry:
    """An index of component manifests. Pure lookup — no execution."""

    def __init__(self, manifests: Iterable[ComponentManifest] = ()) -> None:
        self._by_id: dict[str, ComponentManifest] = {}
        self._index: dict[str, set[str]] | None = None     # term -> component ids
        for m in manifests:
            self.add(m)

    def _ensure_index(self) -> dict[str, set[str]]:
        """Inverted term index over name/description/domain, built lazily."""
        if self._index is None:
            idx: dict[str, set[str]] = {}
            for m in self._by_id.values():
                text = f"{m.name} {m.description} {m.domain} {m.omics_type}".lower()
                for t in set(re.split(r"[^a-z0-9]+", text)):
                    if len(t) > 1:
                        idx.setdefault(t, set()).add(m.id)
            self._index = idx
        return self._index

    # ------------------------------------------------------------------ basics
    def add(self, manifest: ComponentManifest, *, validate: bool = True) -> ComponentManifest:
        if validate:
            errs = manifest.validate()
            if errs:
                manifest.state = LifecycleState.QUARANTINED
                manifest.blocking_reason = "invalid manifest: " + "; ".join(errs)
                self._by_id[manifest.id] = manifest
                return manifest
        if manifest.state is LifecycleState.DISCOVERED:
            manifest.transition(LifecycleState.REGISTERED)
        self._by_id[manifest.id] = manifest
        self._index = None          # invalidate; rebuilt lazily on next search
        return manifest

    def __len__(self) -> int:
        return len(self._by_id)

    def __iter__(self) -> Iterator[ComponentManifest]:
        return iter(self._by_id.values())

    def __contains__(self, cid: object) -> bool:
        return str(cid) in self._by_id

    def get(self, cid: str) -> ComponentManifest | None:
        return self._by_id.get(cid)

    def by_name(self, name: str) -> list[ComponentManifest]:
        n = str(name).lower()
        return [m for m in self._by_id.values() if m.name.lower() == n]

    # ------------------------------------------------------------------ search
    def search(
        self,
        query: str | None = None,
        *,
        kind: str | None = None,
        omics_type: str | None = None,
        project: str | None = None,
        state: LifecycleState | None = None,
        backend: str | None = None,
        ready_only: bool = False,
        limit: int = 20,
    ) -> list[ComponentManifest]:
        """Rank components by term overlap, with composable filters."""
        pool = list(self._by_id.values())
        if kind:
            pool = [m for m in pool if m.kind == kind]
        if omics_type:
            pool = [m for m in pool if m.omics_type == omics_type]
        if project:
            p = project.lower()
            pool = [m for m in pool if p in m.provider.project.lower()]
        if state is not None:
            pool = [m for m in pool if m.state is state]
        if backend:
            pool = [m for m in pool if m.runtime.backend == backend]
        if ready_only:
            pool = [m for m in pool if m.state is LifecycleState.READY]
        if not query:
            return pool[:limit]
        terms = [t for t in re.split(r"[^a-z0-9]+", query.lower()) if len(t) > 1]
        if not terms:
            return pool[:limit]
        # candidate narrowing: only components sharing at least one term
        idx = self._ensure_index()
        hit_ids: set[str] = set()
        for t in terms:
            hit_ids |= idx.get(t, set())
        if hit_ids:
            pool = [m for m in pool if m.id in hit_ids]
        scored: list[tuple[float, ComponentManifest]] = []
        for m in pool:
            name = m.name.lower()
            desc = m.description.lower()
            dom = f"{m.domain} {m.omics_type}".lower()
            s = 0.0
            for t in terms:
                s += name.count(t) * 3.0
                s += 1.5 if t in dom else 0.0
                s += 1.0 if t in desc else 0.0
            if s > 0:
                scored.append((s, m))
        scored.sort(key=lambda x: (-x[0], x[1].id))
        return [m for _, m in scored[:limit]]

    # --------------------------------------------------------------- summaries
    def counts_by(self, attr: str) -> dict[str, int]:
        out: dict[str, int] = {}
        for m in self._by_id.values():
            v = getattr(m, attr, None)
            key = v.value if hasattr(v, "value") else str(v)
            out[key] = out.get(key, 0) + 1
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    def state_census(self) -> dict[str, int]:
        return self.counts_by("state")


@dataclass
class Resolution:
    """Outcome of resolving one component against the live environment."""

    component_id: str
    state: LifecycleState
    missing_python: tuple[str, ...] = ()
    missing_binaries: tuple[str, ...] = ()
    missing_datasets: tuple[str, ...] = ()
    missing_components: tuple[str, ...] = ()
    order: tuple[str, ...] = ()
    reason: str = ""
    fetchable: bool = False
    fetch_command: str = ""

    @property
    def ready(self) -> bool:
        return self.state is LifecycleState.READY


class DependencyCycle(RuntimeError):
    """Raised when component dependencies form a cycle."""


class Resolver:
    """Checks dependency DAGs and the live environment.

    `dataset_probe` lets a caller declare which dataset ids exist locally, so the
    resolver can distinguish "declared" from "present" without importing anything.
    """

    def __init__(self, registry: ComponentRegistry,
                 dataset_probe: Callable[[str], bool] | None = None,
                 service_probe: Callable[[str], bool] | None = None) -> None:
        self.registry = registry
        self._dataset_probe = dataset_probe or (lambda _cid: False)
        self._service_probe = service_probe or (lambda _sid: False)

    # ------------------------------------------------------------ environment
    @staticmethod
    def python_module_available(mod: str) -> bool:
        root = mod.split(".")[0]
        if root in sys.modules:
            return True
        try:
            return importlib.util.find_spec(root) is not None
        except (ImportError, ValueError, ModuleNotFoundError):
            return False

    @staticmethod
    def binary_available(name: str) -> bool:
        return shutil.which(name) is not None

    # ------------------------------------------------------------------- DAG
    def dependency_order(self, cid: str, _seen: tuple[str, ...] = ()) -> list[str]:
        """Topologically order a component's transitive component deps."""
        if cid in _seen:
            raise DependencyCycle(" -> ".join([*_seen, cid]))
        m = self.registry.get(cid)
        if m is None:
            return []
        order: list[str] = []
        for dep in m.requires.components:
            for sub in self.dependency_order(dep, (*_seen, cid)):
                if sub not in order:
                    order.append(sub)
        if cid not in order:
            order.append(cid)
        return order

    def resolve_manifest(self, m: ComponentManifest) -> tuple[bool, str]:
        """Check an unregistered manifest's requirements against the environment.

        Used to score evolution candidates, which are not in the registry yet.
        """
        missing_py = [x for x in m.requires.python if not self.python_module_available(x)]
        missing_bin = [x for x in m.requires.binaries if not self.binary_available(x)]
        missing_ds = [x for x in m.requires.datasets if not self._dataset_probe(x)]
        problems = []
        fetchable, fetch_cmd = False, ""
        if missing_ds and m.runtime.backend == "dataset":
            from ..acquisition.sources import acquisition_for, fetch_command
            if acquisition_for(m) is not None:
                fetchable, fetch_cmd = True, fetch_command(m)
        if missing_py:
            problems.append(f"missing python modules: {', '.join(missing_py[:5])}")
        if missing_bin:
            problems.append(f"missing binaries: {', '.join(missing_bin[:5])}")
        if missing_ds:
            problems.append(("FETCHABLE: " if fetchable else "") +
                            f"missing datasets: {', '.join(missing_ds[:4])}" +
                            (f" — run: {fetch_cmd}" if fetchable else ""))
        if m.runtime.backend == "container":
            problems.append("no container runtime available")
        if m.runtime.backend == "none":
            problems.append("component declares no execution backend")
        return (not problems), "; ".join(problems) or "requirements satisfied"

    # -------------------------------------------------------------- resolve
    def resolve(self, cid: str) -> Resolution:
        m = self.registry.get(cid)
        if m is None:
            return Resolution(cid, LifecycleState.UNAVAILABLE, reason="not in registry")
        if m.state is LifecycleState.QUARANTINED:
            return Resolution(cid, LifecycleState.QUARANTINED, reason=m.blocking_reason)

        try:
            order = tuple(self.dependency_order(cid))
        except DependencyCycle as exc:
            m.mark_unavailable(f"dependency cycle: {exc}")
            return Resolution(cid, LifecycleState.UNAVAILABLE, reason=str(exc))

        missing_py = tuple(x for x in m.requires.python if not self.python_module_available(x))
        missing_bin = tuple(x for x in m.requires.binaries if not self.binary_available(x))
        missing_ds = tuple(x for x in m.requires.datasets if not self._dataset_probe(x))
        missing_comp = tuple(x for x in m.requires.components if x not in self.registry)
        missing_svc = tuple(x for x in m.requires.services if not self._service_probe(x))

        problems = []
        fetchable, fetch_cmd = False, ""
        if missing_ds and m.runtime.backend == "dataset":
            from ..acquisition.sources import acquisition_for, fetch_command
            if acquisition_for(m) is not None:
                fetchable, fetch_cmd = True, fetch_command(m)
        if missing_py:
            problems.append(f"missing python modules: {', '.join(missing_py[:6])}")
        if missing_bin:
            problems.append(f"missing binaries: {', '.join(missing_bin[:6])}")
        if missing_ds:
            problems.append(("FETCHABLE: " if fetchable else "") +
                            f"missing datasets: {', '.join(missing_ds[:4])}" +
                            (f" — run: {fetch_cmd}" if fetchable else ""))
        if missing_comp:
            problems.append(f"missing components: {', '.join(missing_comp[:4])}")
        if missing_svc:
            problems.append(f"missing services: {', '.join(missing_svc[:4])}")
        if m.runtime.backend == "container":
            problems.append("container backend requires a container runtime (none available)")
        if m.runtime.backend == "none":
            problems.append("no execution backend declared (catalogue metadata only)")

        if problems:
            reason = "; ".join(problems)
            m.mark_unavailable(reason)
            return Resolution(cid, LifecycleState.UNAVAILABLE, missing_py, missing_bin,
                              missing_ds, missing_comp, order, reason,
                              fetchable=fetchable, fetch_command=fetch_cmd)

        if m.state in (LifecycleState.REGISTERED, LifecycleState.UNAVAILABLE):
            m.mark_recovered(LifecycleState.AVAILABLE)
        if m.state is LifecycleState.AVAILABLE:
            m.transition(LifecycleState.RESOLVED)
        # Backends that need no import (datasets) are invocable as soon as their
        # declared inputs exist, so RESOLVED already implies READY for them.
        if m.runtime.backend == "dataset" and m.state is LifecycleState.RESOLVED:
            m.transition(LifecycleState.LOADED)
            m.transition(LifecycleState.READY)
        return Resolution(cid, m.state, order=order, reason="dependencies satisfied")


class Loader:
    """Lazily imports component implementations and caches them."""

    def __init__(self, registry: ComponentRegistry, resolver: Resolver | None = None) -> None:
        self.registry = registry
        self.resolver = resolver or Resolver(registry)
        self._cache: dict[str, Any] = {}
        self.load_count = 0
        self.unload_count = 0

    @property
    def loaded_ids(self) -> tuple[str, ...]:
        return tuple(self._cache)

    def load(self, cid: str) -> Any:
        """Import and return the callable for a component, or None if blocked."""
        if cid in self._cache:
            return self._cache[cid]
        m = self.registry.get(cid)
        if m is None:
            return None
        res = self.resolver.resolve(cid)
        if not (res.state is LifecycleState.RESOLVED or res.state is LifecycleState.READY):
            return None
        if m.runtime.backend != "python":
            # Non-import backends have nothing to load. READY is granted only by
            # a successful invocation through the backend (Runtime.invoke), never
            # here — the v2 defect marked mcp/http components READY with no proof.
            return None
        target = m.runtime.entrypoint
        if ":" not in target:
            m.mark_unavailable(f"malformed entrypoint {target!r} (expected 'module:function')")
            return None
        mod_name, _, fn_name = target.partition(":")
        try:
            mod = importlib.import_module(mod_name)
            fn = getattr(mod, fn_name)
        except Exception as exc:  # noqa: BLE001 - recorded as a blocking reason
            m.mark_unavailable(f"import failed: {type(exc).__name__}: {exc}")
            return None
        self._cache[cid] = fn
        self.load_count += 1
        if m.state is LifecycleState.RESOLVED:
            m.transition(LifecycleState.LOADED)
        if m.state is LifecycleState.LOADED:
            m.transition(LifecycleState.READY)
        return fn

    def unload(self, cid: str) -> bool:
        """Drop a cached implementation, returning the component to LOADED."""
        if cid not in self._cache:
            return False
        del self._cache[cid]
        self.unload_count += 1
        m = self.registry.get(cid)
        if m is not None and m.state is LifecycleState.READY:
            m.transition(LifecycleState.LOADED)
        return True

    def unload_all(self) -> int:
        n = 0
        for cid in list(self._cache):
            n += bool(self.unload(cid))
        return n
